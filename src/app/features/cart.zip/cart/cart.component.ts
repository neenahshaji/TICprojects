import { Component, NO_ERRORS_SCHEMA, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ApiService } from 'src/app/services';
import { cartItemList, CartService, Product, rate } from 'src/app/services/cart.service';
@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.scss']
})
export class CartComponent implements OnInit{
  products : Product[] = [];
  details : any;
  rates:any;
  cartItems :cartItemList[] | undefined;
  response:any;
  orderForm!: FormGroup;
  placeorder!: FormGroup;
  Salesorder:any;
  displayModal!: boolean;
  displayyModal!: boolean;
  t_gross:number;
  t_net:number;
  getordersdata : any;
  visibleSidebar5 : any;
  orderupdate:string = "false";
  
  id: number;
  customerId:number;
  constructor(private cartService : CartService,private apiService: ApiService ){}

  ngOnInit(): void

   {
    this.products=this.cartService.getProducts()
   
    this.orderForm = new FormGroup({
        'address': new FormControl('', Validators.required)
    })

    this.placeorder = new FormGroup({
      'poNumber': new FormControl('', Validators.required),
      'remarks': new FormControl('', Validators.required)
  
  })

  // this.display();

  }

  removeFromCart(product : Product)
  {
    const index = this.products.indexOf(product, 0);
      if (index > -1)
      {
          this.products.splice(index, 1);
          localStorage.setItem('cartItemList',JSON.stringify(this.products));
      }
  }

  showModalDialog() 
  {
    this.displayModal = true;
  }

  placeOrderrr()
  {
    this.details = [];
    this.t_gross=0;
    this.t_net=0;
    this.products.forEach((item) => {
      this.rates = item.rates;
      let obj = {
        id:0,
        itemCode: item['partNumber'],
        itemName: item['description'],
        qty:item['quantity'],
        rate:0,
        grossAmount:73,
        discount:0,
        vat:0,
        netAmount:73,
        uom:'NOS'
      }
      this.rates.forEach((rate) =>{
        if(obj.uom==rate.uomCode){      
        obj.rate=rate.rate
        obj.grossAmount=obj.rate*obj.qty
        this.t_gross=this.t_gross+obj.grossAmount
        obj.netAmount=obj.grossAmount-obj.discount
        this.t_net=this.t_net+obj.netAmount
        }
      })      
      this.details.push(obj) 
      console.log("details:",this.details);     
    });   
    console.log("deatils",this.details)
    let Salesorder= {
      id: 0,
      customerId: 4094,
      customerName: '',
      customerCity: '',
      orderDate:new Date(),
      grossAmount: this.t_gross,
      discount: 0,
      vat: 0,
      netAmount: this.t_net,
      remarks:this.placeorder.value.remarks,
      poNumber: this.placeorder.value.poNumber,
      address: this.orderForm.value.address,
      details:this.details
    }
    console.log("final:",Salesorder);
   
    this.apiService.createCart(4094,Salesorder).subscribe((response) => {  
      this.response=response;
      if(response.code ==200)
      {
        this.displayyModal=true
        this.displayModal=false
      }
      else
      {
      console.log("erorr")
      }
    })
   console.log("orderupdate",this.orderupdate)
  }

  display()
  {
    this.visibleSidebar5 = true 
    debugger;
    this.displayyModal=false
    this.visibleSidebar5 = true 
    this.id = Number(this.apiService.getOrderId())  
    this.customerId=Number(this.apiService.getCustomerId())
    this.apiService.GetOrder(this.customerId,this.id).subscribe(response =>{   
      this.getordersdata =response.order;       
      console.log("response:",response);  
    })
  }
  
}

